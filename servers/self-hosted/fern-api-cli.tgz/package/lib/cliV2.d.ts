import { Argv } from "yargs";
import { CliContext } from "./cli-context/CliContext";
import { GlobalCliOptions } from "./cliCommons";
export declare function addGetOrganizationCommand(cli: Argv<GlobalCliOptions>, cliContext: CliContext): void;
export declare function addGeneratorCommands(cli: Argv<GlobalCliOptions>, cliContext: CliContext): void;
