import { LogLevel } from "@fern-api/logger";
import { Project } from "@fern-api/project-loader";
import { Finishable, PosthogEvent, Startable, TaskContext } from "@fern-api/task-context";
import { Workspace } from "@fern-api/workspace-loader";
import { CliEnvironment } from "./CliEnvironment";
import { FernGeneratorUpgradeInfo } from "./upgrade-utils/getGeneratorVersions";
export interface FernCliUpgradeInfo {
    isUpgradeAvailable: boolean;
    latestVersion: string;
}
export interface FernUpgradeInfo {
    cliUpgradeInfo: FernCliUpgradeInfo | undefined;
    generatorUpgradeInfo: FernGeneratorUpgradeInfo[];
}
export declare class CliContext {
    readonly environment: CliEnvironment;
    private didSucceed;
    private numTasks;
    private ttyAwareLogger;
    private logLevel;
    private isLocal;
    constructor(stdout: NodeJS.WriteStream, stderr: NodeJS.WriteStream, { isLocal }: {
        isLocal?: boolean;
    });
    private getPackageName;
    private getPackageVersion;
    private getCliName;
    setLogLevel(logLevel: LogLevel): void;
    logDebugInfo(): void;
    failAndThrow(message?: string, error?: unknown): never;
    failWithoutThrowing(message?: string, error?: unknown): void;
    exit({ code }?: {
        code?: number;
    }): Promise<never>;
    private nudgeUpgradeIfAvailable;
    exitIfFailed(): Promise<void>;
    private exitProgram;
    private longestWorkspaceName;
    registerWorkspaces(workspaces: readonly Workspace[]): void;
    private project;
    registerProject(project: Project): void;
    runTask<T>(run: (context: TaskContext) => T | Promise<T>): Promise<T>;
    addTask(): Startable<TaskContext & Finishable>;
    runTaskForWorkspace(workspace: Workspace, run: (context: TaskContext) => void | Promise<void>): Promise<void>;
    private addTaskWithInit;
    private readonly USE_NODE_18_OR_ABOVE_MESSAGE;
    private runTaskWithInit;
    instrumentPostHogEvent(event: PosthogEvent): Promise<void>;
    readonly logger: import("@fern-api/logger").Logger;
    readonly stderr: import("@fern-api/logger").Logger;
    private constructTaskInitForWorkspace;
    private constructTaskInit;
    private log;
    private logStderr;
    private logImmediately;
    private _suppressUpgradeMessage;
    suppressUpgradeMessage(): void;
    private _isUpgradeAvailable;
    isUpgradeAvailable({ includePreReleases }?: {
        includePreReleases?: boolean;
    }): Promise<FernUpgradeInfo>;
    /**
     * Prompts the user for confirmation with a yes/no question
     * @param message The message to display to the user
     * @param defaultValue Optional default value (defaults to false)
     * @returns Promise<boolean> representing the user's choice
     */
    confirmPrompt(message: string, defaultValue?: boolean): Promise<boolean>;
    /**
     * Prompts the user for text input
     * @param message The message to display to the user
     * @param default Optional default value (defaults to undefined)
     * @returns Promise<string> representing the user's input
     */
    getInput(config: {
        message: string;
        default?: string;
    }): Promise<string>;
}
