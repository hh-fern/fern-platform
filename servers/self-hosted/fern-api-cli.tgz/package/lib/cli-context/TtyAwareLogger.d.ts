import { Log } from "./Log";
import { TaskContextImpl } from "./TaskContextImpl";
export declare class TtyAwareLogger {
    private readonly stdout;
    private readonly stderr;
    private tasks;
    private lastPaint;
    private spinner;
    private interval;
    constructor(stdout: NodeJS.WriteStream, stderr: NodeJS.WriteStream);
    private start;
    finish: () => void;
    private paintAndStartInterval;
    registerTask(context: TaskContextImpl): void;
    private shouldBuffer;
    private buffer;
    private writeStdout;
    private writeStderr;
    private startBuffering;
    private flushAndStopBuffering;
    takeOverTerminal(run: () => void | Promise<void>): Promise<void>;
    log(logs: Log[], { includeDebugInfo, stderr }?: {
        includeDebugInfo?: boolean;
        stderr?: boolean;
    }): void;
    private repaint;
    private clear;
    private paint;
    get isTTY(): boolean;
}
