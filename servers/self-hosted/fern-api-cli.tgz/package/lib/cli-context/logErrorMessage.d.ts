import { LogLevel, Logger } from "@fern-api/logger";
export declare function logErrorMessage({ message, error, logger, logLevel }: {
    message: string | undefined;
    error: unknown;
    logger: Logger;
    logLevel?: LogLevel;
}): void;
