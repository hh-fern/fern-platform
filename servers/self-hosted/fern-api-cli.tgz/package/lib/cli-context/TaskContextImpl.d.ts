import { LogLevel } from "@fern-api/logger";
import { CreateInteractiveTaskParams, Finishable, InteractiveTaskContext, PosthogEvent, Startable, TaskContext, TaskResult } from "@fern-api/task-context";
import { Log } from "./Log";
export declare namespace TaskContextImpl {
    interface Init {
        logImmediately: (logs: Log[]) => void;
        takeOverTerminal: (run: () => void | Promise<void>) => Promise<void>;
        logPrefix?: string;
        /**
         * called when this task or any subtask finishes
         */
        onResult?: (result: TaskResult) => void;
        shouldBufferLogs: boolean;
        instrumentPostHogEvent: (event: PosthogEvent) => Promise<void>;
    }
}
export declare class TaskContextImpl implements Startable<TaskContext>, Finishable, TaskContext {
    protected result: TaskResult;
    protected logImmediately: (logs: Log[]) => void;
    protected logPrefix: string;
    protected subtasks: InteractiveTaskContextImpl[];
    private shouldBufferLogs;
    private bufferedLogs;
    protected status: "notStarted" | "running" | "finished";
    private onResult;
    private instrumentPostHogEventImpl;
    constructor({ logImmediately, logPrefix, takeOverTerminal, onResult, shouldBufferLogs, instrumentPostHogEvent }: TaskContextImpl.Init);
    start(): Finishable & TaskContext;
    isStarted(): boolean;
    finish(): void;
    isFinished(): boolean;
    takeOverTerminal: (run: () => void | Promise<void>) => Promise<void>;
    failAndThrow(message?: string, error?: unknown): never;
    failWithoutThrowing(message?: string, error?: unknown): void;
    getResult(): TaskResult;
    instrumentPostHogEvent(event: PosthogEvent): Promise<void>;
    protected logAtLevel(level: LogLevel, ...parts: string[]): void;
    protected logAtLevelWithOverrides(level: LogLevel, parts: string[], overrides?: Pick<Log, "omitOnTTY">): void;
    protected log(log: Log): void;
    protected flushLogs(): void;
    readonly logger: import("@fern-api/logger").Logger;
    addInteractiveTask({ name, subtitle }: CreateInteractiveTaskParams): Startable<InteractiveTaskContext>;
    runInteractiveTask(params: CreateInteractiveTaskParams, run: (context: InteractiveTaskContext) => void | Promise<void>): Promise<boolean>;
    printInteractiveTasks({ spinner }: {
        spinner: string;
    }): string;
}
/**
 * InteractiveTaskContextImpl is defined in this file because
 * InteractiveTaskContextImpl and TaskContextImpl are co-dependent
 */
export declare namespace InteractiveTaskContextImpl {
    interface Init extends TaskContextImpl.Init {
        name: string;
        subtitle: string | undefined;
    }
}
export declare class InteractiveTaskContextImpl extends TaskContextImpl implements Startable<InteractiveTaskContext>, Finishable, InteractiveTaskContext {
    private name;
    private subtitle;
    constructor({ name, subtitle, ...superArgs }: InteractiveTaskContextImpl.Init);
    start(): Finishable & InteractiveTaskContext;
    isStarted(): boolean;
    finish(): void;
    setSubtitle(subtitle: string | undefined): void;
    print({ spinner }: {
        spinner: string;
    }): string;
    printInteractiveTasks({ spinner }: {
        spinner: string;
    }): string;
    private getIcon;
    getResult(): TaskResult;
}
