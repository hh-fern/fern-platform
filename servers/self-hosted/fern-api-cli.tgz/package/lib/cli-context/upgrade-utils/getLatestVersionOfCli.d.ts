import { CliEnvironment } from "../CliEnvironment";
export declare function getLatestVersionOfCli({ cliEnvironment, includePreReleases }: {
    cliEnvironment: CliEnvironment;
    includePreReleases?: boolean;
}): Promise<string>;
