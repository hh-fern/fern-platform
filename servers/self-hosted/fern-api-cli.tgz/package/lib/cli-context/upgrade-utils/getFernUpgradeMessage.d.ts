import { FernUpgradeInfo } from "../CliContext";
import { CliEnvironment } from "../CliEnvironment";
import { FernGeneratorUpgradeInfo } from "./getGeneratorVersions";
export declare function getFernUpgradeMessage({ cliEnvironment, upgradeInfo }: {
    cliEnvironment: CliEnvironment;
    upgradeInfo: FernUpgradeInfo;
}): Promise<string | undefined>;
export declare function getGeneratorUpgradeMessage({ generatorUpgradeInfo, header, limit, includeBoxen }: {
    generatorUpgradeInfo: FernGeneratorUpgradeInfo[];
    header?: string;
    limit?: number;
    includeBoxen?: boolean;
}): Promise<string | undefined>;
