import { Logger } from "@fern-api/logger";
import { Project } from "@fern-api/project-loader";
import { ReleaseType } from "@fern-fern/generators-sdk/api/resources/generators";
import { CliContext } from "../CliContext";
export interface FernGeneratorUpgradeInfo {
    generatorName: string;
    generatorGroup: string;
    apiName: string | undefined;
    isUpgradeAvailable: boolean;
    currentVersion: string;
    latestVersion: string;
}
interface VersionDiff {
    previousVersion: string;
    latestVersion: string;
}
export type GroupedGeneratorVersions = Record<string, Record<string, VersionDiff>>;
interface SingleApiWorkspaceGeneratorVersions {
    type: "singleApi";
    versions: GroupedGeneratorVersions;
}
interface MultiApiWorkspaceGeneratorVersions {
    type: "multiApi";
    versions: Record<string, GroupedGeneratorVersions>;
}
export type GeneratorVersions = MultiApiWorkspaceGeneratorVersions | SingleApiWorkspaceGeneratorVersions;
export declare function getLatestGeneratorVersions({ cliContext, project: { apiWorkspaces }, generatorFilter, groupFilter, channel, includeMajor }: {
    cliContext: CliContext;
    project: Project;
    generatorFilter?: string;
    groupFilter?: string;
    channel?: ReleaseType;
    includeMajor?: boolean;
}): Promise<GeneratorVersions>;
export declare function processGeneratorGroups(groups: GroupedGeneratorVersions, maybeApiName: string | undefined, logger: Logger): FernGeneratorUpgradeInfo[];
export declare function getProjectGeneratorUpgrades({ project, cliContext, generatorFilter, groupFilter, channel, includeMajor }: {
    project: Project | undefined;
    cliContext: CliContext;
    generatorFilter?: string;
    groupFilter?: string;
    channel?: ReleaseType;
    includeMajor?: boolean;
}): Promise<FernGeneratorUpgradeInfo[]>;
export {};
