import { CliEnvironment } from "../CliEnvironment";
export declare function doesVersionOfCliExist({ cliEnvironment, version }: {
    cliEnvironment: CliEnvironment;
    version: string;
}): Promise<boolean>;
