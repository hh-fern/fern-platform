import { AbsoluteFilePath } from "@fern-api/fs-utils";
export declare function getPathToOutputDirectoriesFile(): AbsoluteFilePath;
