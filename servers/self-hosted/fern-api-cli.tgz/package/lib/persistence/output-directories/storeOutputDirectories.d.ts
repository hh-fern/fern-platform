import { AbsoluteFilePath } from "@fern-api/fs-utils";
export declare function storeOutputDirectories(outputDirectories: AbsoluteFilePath[]): Promise<void>;
