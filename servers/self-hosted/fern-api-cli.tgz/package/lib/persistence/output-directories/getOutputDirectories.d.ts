import { AbsoluteFilePath } from "@fern-api/fs-utils";
export declare function getOutputDirectories(): Promise<AbsoluteFilePath[]>;
