import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function generateJsonschemaForWorkspaces({ typeLocator, project, jsonschemaFilepath, cliContext }: {
    typeLocator: string;
    project: Project;
    jsonschemaFilepath: AbsoluteFilePath;
    cliContext: CliContext;
}): Promise<void>;
