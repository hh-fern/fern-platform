import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { CliContext } from "../../cli-context/CliContext";
export interface CheckOutputDirectoryResult {
    shouldProceed: boolean;
}
/**
 * Checks if an output directory is safe to write to and handles user confirmations
 * @param outputPath The path to check
 * @param cliContext The CLI context for prompting
 * @returns Object containing whether to proceed and if directory was saved
 */
export declare function checkOutputDirectory(outputPath: AbsoluteFilePath | undefined, cliContext: CliContext, force: boolean): Promise<CheckOutputDirectoryResult>;
