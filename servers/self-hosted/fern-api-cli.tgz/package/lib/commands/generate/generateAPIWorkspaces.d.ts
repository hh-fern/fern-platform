import { ContainerRunner, Values } from "@fern-api/core-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare const GenerationMode: {
    readonly PullRequest: "pull-request";
};
export type GenerationMode = Values<typeof GenerationMode>;
export declare function generateAPIWorkspaces({ project, cliContext, version, groupName, shouldLogS3Url, keepDocker, useLocalDocker, preview, mode, force, runner }: {
    project: Project;
    cliContext: CliContext;
    version: string | undefined;
    groupName: string | undefined;
    shouldLogS3Url: boolean;
    useLocalDocker: boolean;
    keepDocker: boolean;
    preview: boolean;
    mode: GenerationMode | undefined;
    force: boolean;
    runner: ContainerRunner | undefined;
}): Promise<void>;
