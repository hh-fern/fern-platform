import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function previewDocsWorkspace({ loadProject, cliContext, port, bundlePath, brokenLinks, appPreview, legacyPreview, backendPort }: {
    loadProject: () => Promise<Project>;
    cliContext: CliContext;
    port: number;
    bundlePath?: string;
    brokenLinks: boolean;
    appPreview?: boolean;
    legacyPreview?: boolean;
    backendPort: number;
}): Promise<void>;
