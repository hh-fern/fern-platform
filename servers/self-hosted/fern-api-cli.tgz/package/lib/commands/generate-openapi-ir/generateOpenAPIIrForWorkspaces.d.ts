import { generatorsYml } from "@fern-api/configuration-loader";
import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function generateOpenAPIIrForWorkspaces({ project, irFilepath, cliContext, sdkLanguage }: {
    project: Project;
    irFilepath: AbsoluteFilePath;
    cliContext: CliContext;
    sdkLanguage: generatorsYml.GenerationLanguage | undefined;
}): Promise<void>;
