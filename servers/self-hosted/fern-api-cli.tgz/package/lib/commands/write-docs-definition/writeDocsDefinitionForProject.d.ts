import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function writeDocsDefinitionForProject({ project, outputPath, cliContext }: {
    project: Project;
    outputPath: string;
    cliContext: CliContext;
}): Promise<void>;
