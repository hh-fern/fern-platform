import { Audiences, generatorsYml } from "@fern-api/configuration-loader";
import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function generateDynamicIrForWorkspaces({ project, irFilepath, cliContext, generationLanguage, audiences, version, keywords, smartCasing, disableDynamicExamples }: {
    project: Project;
    irFilepath: AbsoluteFilePath;
    cliContext: CliContext;
    generationLanguage: generatorsYml.GenerationLanguage | undefined;
    audiences: Audiences;
    version: string | undefined;
    keywords: string[] | undefined;
    smartCasing: boolean;
    disableDynamicExamples: boolean;
}): Promise<void>;
