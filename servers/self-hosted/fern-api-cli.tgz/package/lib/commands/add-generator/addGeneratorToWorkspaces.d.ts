import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function addGeneratorToWorkspaces({ project: { apiWorkspaces }, generatorName, groupName, cliContext }: {
    project: Project;
    generatorName: string;
    groupName: string | undefined;
    cliContext: CliContext;
}): Promise<void>;
