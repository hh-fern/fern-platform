import { generatorsYml } from "@fern-api/configuration-loader";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function writeDefinitionForWorkspaces({ project, cliContext, sdkLanguage, preserveSchemaIds }: {
    project: Project;
    cliContext: CliContext;
    sdkLanguage: generatorsYml.GenerationLanguage | undefined;
    preserveSchemaIds: boolean;
}): Promise<void>;
