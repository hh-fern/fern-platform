import { Audiences, generatorsYml } from "@fern-api/configuration-loader";
import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function generateIrForWorkspaces({ project, irFilepath, cliContext, generationLanguage, audiences, version, keywords, smartCasing, readme, directFromOpenapi, disableExamples }: {
    project: Project;
    irFilepath: AbsoluteFilePath;
    cliContext: CliContext;
    generationLanguage: generatorsYml.GenerationLanguage | undefined;
    audiences: Audiences;
    version: string | undefined;
    keywords: string[] | undefined;
    smartCasing: boolean;
    readme: generatorsYml.ReadmeSchema | undefined;
    directFromOpenapi: boolean;
    disableExamples: boolean;
}): Promise<void>;
