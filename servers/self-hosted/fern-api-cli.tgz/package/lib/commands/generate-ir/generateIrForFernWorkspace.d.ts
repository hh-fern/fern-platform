import { FernWorkspace } from "@fern-api/api-workspace-commons";
import { Audiences, generatorsYml } from "@fern-api/configuration-loader";
import { IntermediateRepresentation } from "@fern-api/ir-sdk";
import { TaskContext } from "@fern-api/task-context";
export declare function generateIrForFernWorkspace({ workspace, context, generationLanguage, keywords, smartCasing, disableExamples, audiences, readme, disableDynamicExamples }: {
    workspace: FernWorkspace;
    context: TaskContext;
    generationLanguage: generatorsYml.GenerationLanguage | undefined;
    keywords: string[] | undefined;
    smartCasing: boolean;
    disableExamples: boolean;
    audiences: Audiences;
    readme: generatorsYml.ReadmeSchema | undefined;
    disableDynamicExamples: boolean;
}): Promise<IntermediateRepresentation>;
