import { generatorsYml } from "@fern-api/configuration-loader";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function getGeneratorMetadata({ cliContext, generatorFilter, groupFilter, apiFilter, project: { apiWorkspaces } }: {
    cliContext: CliContext;
    generatorFilter: string;
    groupFilter: string;
    apiFilter: string | undefined;
    project: Project;
}): Promise<generatorsYml.GeneratorInvocation | undefined>;
