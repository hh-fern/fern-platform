import { Values } from "@fern-api/core-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare const GenerationModeFilter: {
    readonly GitHub: "github";
    readonly Local: "local-file-system";
    readonly PackageRegistry: "publish";
};
export type GenerationModeFilter = Values<typeof GenerationModeFilter>;
export declare function getGeneratorList({ cliContext, generatorFilter, groupFilter, apiFilter, apiKeyFallback, project: { apiWorkspaces }, outputLocation, excludedModes, includedModes }: {
    cliContext: CliContext;
    generatorFilter: Set<string> | undefined;
    groupFilter: Set<string> | undefined;
    apiFilter: Set<string> | undefined;
    project: Project;
    apiKeyFallback: string | undefined;
    outputLocation: string | undefined;
    excludedModes: Set<GenerationModeFilter> | undefined;
    includedModes: Set<GenerationModeFilter> | undefined;
}): Promise<void>;
