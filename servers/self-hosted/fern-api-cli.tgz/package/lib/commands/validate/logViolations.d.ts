import { ValidationViolation } from "@fern-api/fern-definition-validator";
import { TaskContext } from "@fern-api/task-context";
export interface LogViolationsResponse {
    hasErrors: boolean;
}
export declare function logViolations({ context, violations, logWarnings, logSummary, logBreadcrumbs, elapsedMillis }: {
    context: TaskContext;
    violations: ValidationViolation[];
    logWarnings: boolean;
    logSummary?: boolean;
    logBreadcrumbs?: boolean;
    elapsedMillis?: number;
}): LogViolationsResponse;
