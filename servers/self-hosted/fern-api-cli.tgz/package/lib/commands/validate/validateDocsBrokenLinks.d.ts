import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function validateDocsBrokenLinks({ project, cliContext, errorOnBrokenLinks }: {
    project: Project;
    cliContext: CliContext;
    errorOnBrokenLinks: boolean;
}): Promise<void>;
