import { FernWorkspace } from "@fern-api/api-workspace-commons";
import { OSSWorkspace } from "@fern-api/lazy-fern-workspace";
import { TaskContext } from "@fern-api/task-context";
export declare function validateAPIWorkspaceWithoutExiting({ workspace, context, logWarnings, logSummary, ossWorkspace }: {
    workspace: FernWorkspace;
    context: TaskContext;
    logWarnings: boolean;
    logSummary?: boolean;
    ossWorkspace?: OSSWorkspace;
}): Promise<{
    hasErrors: boolean;
}>;
export declare function validateAPIWorkspaceAndLogIssues({ workspace, context, logWarnings, ossWorkspace }: {
    workspace: FernWorkspace;
    context: TaskContext;
    logWarnings: boolean;
    ossWorkspace?: OSSWorkspace;
}): Promise<void>;
