import { OSSWorkspace } from "@fern-api/lazy-fern-workspace";
import { TaskContext } from "@fern-api/task-context";
import { AbstractAPIWorkspace, DocsWorkspace } from "@fern-api/workspace-loader";
export declare function validateDocsWorkspaceWithoutExiting({ workspace, apiWorkspaces, ossWorkspaces, context, logWarnings, errorOnBrokenLinks, logSummary, excludeRules }: {
    workspace: DocsWorkspace;
    apiWorkspaces: AbstractAPIWorkspace<unknown>[];
    ossWorkspaces: OSSWorkspace[];
    context: TaskContext;
    logWarnings: boolean;
    errorOnBrokenLinks?: boolean;
    logSummary?: boolean;
    excludeRules?: string[];
}): Promise<{
    hasErrors: boolean;
}>;
export declare function validateDocsWorkspaceAndLogIssues({ workspace, apiWorkspaces, ossWorkspaces, context, logWarnings, errorOnBrokenLinks, excludeRules }: {
    workspace: DocsWorkspace;
    apiWorkspaces: AbstractAPIWorkspace<unknown>[];
    ossWorkspaces: OSSWorkspace[];
    context: TaskContext;
    logWarnings: boolean;
    errorOnBrokenLinks?: boolean;
    excludeRules?: string[];
}): Promise<void>;
