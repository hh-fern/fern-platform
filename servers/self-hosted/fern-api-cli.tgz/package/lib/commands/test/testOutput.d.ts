import { generatorsYml } from "@fern-api/configuration-loader";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function testOutput({ cliContext, project, testCommand, generationLanguage }: {
    cliContext: CliContext;
    project: Project;
    testCommand: string | undefined;
    generationLanguage: generatorsYml.GenerationLanguage | undefined;
}): Promise<void>;
