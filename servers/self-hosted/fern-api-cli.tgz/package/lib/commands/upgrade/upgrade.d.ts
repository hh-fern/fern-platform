import { CliContext } from "../../cli-context/CliContext";
export declare const PREVIOUS_VERSION_ENV_VAR = "FERN_PRE_UPGRADE_VERSION";
/**
 * there are 3 relevant versions:
 *   1. the version of the CLI specified in fern.config.json
 *   2. the version of the CLI being run right now.
 *   3. the version of the CLI we're upgrading to (can be passed in, but default
 *      to the latest published version)
 *
 * When the CLI is first invoked, if the version of the CLI is not equal to
 * the version in fern.config.json, we immediately re-run the CLI at the
 * version specified in fern.config.json. So by the time we're here, we can
 * assume that version #1 == version #2.
 *
 * if #3 is the same version as #1 and #2 (i.e. we're already at the target version),
 * then this function simply prints "No upgrade available." and returns.
 *
 * otherwise, if an upgrade is available, this function:
 *   1. upgrades the globally-installed version of the CLI to the target version
 *   2. change the version in fern.config.json to the target version
 *   3. re-runs `fern upgrade` using the latest version the CLI
 *        implementation detail: when doing so, we set the PREVIOUS_VERSION_ENV_VAR
 *        so we know what version we just upgraded from
 *   4. During this re-run, this function is invoked again. During this re-run,
 *      we run any migrations between PREVIOUS_VERSION_ENV_VAR and the target
 *      version of the CLI.
 */
export declare function upgrade({ cliContext, includePreReleases, targetVersion }: {
    cliContext: CliContext;
    includePreReleases: boolean;
    targetVersion: string | undefined;
}): Promise<void>;
