import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { TaskContext } from "@fern-api/task-context";
import { FernRegistry } from "@fern-fern/generators-sdk";
import { CliContext } from "../../cli-context/CliContext";
export declare function loadAndUpdateGenerators({ absolutePathToWorkspace, context, generatorFilter, groupFilter, includeMajor, channel, cliVersion }: {
    absolutePathToWorkspace: AbsoluteFilePath;
    context: TaskContext;
    generatorFilter: string | undefined;
    groupFilter: string | undefined;
    includeMajor: boolean;
    channel: FernRegistry.generators.ReleaseType | undefined;
    cliVersion: string;
}): Promise<string | undefined>;
export declare function upgradeGenerator({ cliContext, generator, group, project: { apiWorkspaces }, includeMajor, channel }: {
    cliContext: CliContext;
    generator: string | undefined;
    group: string | undefined;
    project: Project;
    includeMajor: boolean;
    channel: FernRegistry.generators.ReleaseType | undefined;
}): Promise<void>;
