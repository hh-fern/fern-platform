import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function updateApiSpec({ cliContext, project: { apiWorkspaces } }: {
    cliContext: CliContext;
    project: Project;
}): Promise<void>;
