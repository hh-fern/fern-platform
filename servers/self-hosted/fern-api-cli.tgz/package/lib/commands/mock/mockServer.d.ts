import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function mockServer({ cliContext, project, port }: {
    cliContext: CliContext;
    project: Project;
    port: number | undefined;
}): Promise<void>;
