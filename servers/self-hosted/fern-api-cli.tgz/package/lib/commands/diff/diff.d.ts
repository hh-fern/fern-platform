import { CliContext } from "../../cli-context/CliContext";
export interface Result {
    bump: "major" | "minor" | "patch";
    nextVersion?: string;
    errors: string[];
}
export declare function diff({ context, from, to, fromVersion }: {
    context: CliContext;
    from: string;
    to: string;
    fromVersion: string | undefined;
}): Promise<Result>;
