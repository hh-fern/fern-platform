import { FernToken } from "@fern-api/auth";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function registerWorkspacesV2({ project, cliContext, token }: {
    project: Project;
    cliContext: CliContext;
    token: FernToken;
}): Promise<void>;
