import { FernToken } from "@fern-api/auth";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function registerWorkspacesV1({ project, cliContext, token, version }: {
    project: Project;
    cliContext: CliContext;
    token: FernToken;
    version: string | undefined;
}): Promise<void>;
