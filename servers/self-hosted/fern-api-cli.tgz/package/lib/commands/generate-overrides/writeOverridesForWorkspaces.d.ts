import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function writeOverridesForWorkspaces({ project, includeModels, cliContext }: {
    project: Project;
    includeModels: boolean;
    cliContext: CliContext;
}): Promise<void>;
