import { TaskContext } from "@fern-api/task-context";
export declare function generateToken({ orgId, taskContext }: {
    orgId: string;
    taskContext: TaskContext;
}): Promise<void>;
