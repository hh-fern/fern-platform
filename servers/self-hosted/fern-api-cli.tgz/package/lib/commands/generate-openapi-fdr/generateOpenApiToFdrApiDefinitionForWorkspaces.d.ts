import { Audiences } from "@fern-api/configuration";
import { AbsoluteFilePath } from "@fern-api/fs-utils";
import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function generateOpenApiToFdrApiDefinitionForWorkspaces({ project, outputFilepath, cliContext, directFromOpenapi, audiences }: {
    project: Project;
    outputFilepath: AbsoluteFilePath;
    cliContext: CliContext;
    directFromOpenapi: boolean;
    audiences: Audiences;
}): Promise<void>;
