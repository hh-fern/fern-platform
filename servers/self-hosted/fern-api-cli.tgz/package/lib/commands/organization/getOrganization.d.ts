import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function getOrganization({ project, outputLocation, context }: {
    project: Project;
    outputLocation: string | undefined;
    context: CliContext;
}): Promise<void>;
