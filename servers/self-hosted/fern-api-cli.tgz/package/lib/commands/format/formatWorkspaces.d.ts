import { Project } from "@fern-api/project-loader";
import { CliContext } from "../../cli-context/CliContext";
export declare function formatWorkspaces({ project, cliContext, shouldFix }: {
    project: Project;
    cliContext: CliContext;
    shouldFix: boolean;
}): Promise<void>;
