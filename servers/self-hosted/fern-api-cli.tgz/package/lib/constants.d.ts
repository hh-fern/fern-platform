export declare const API_CLI_OPTION = "api";
export declare const GROUP_CLI_OPTION = "group";
export declare const TOKEN_STDIN_OPTION = "token-stdin";
export declare const PREVIEW_DIRECTORY = ".preview";
export declare const APPROVED_DIRECTORIES_FILENAME = "approved-output-directories";
export declare const LOCAL_STORAGE_FOLDER: string;
