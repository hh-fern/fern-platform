export declare const FERN_CWD_ENV_VAR = "FERN_CWD";
