import { LogLevel } from "@fern-api/logger";
import { Project, loadProject } from "@fern-api/project-loader";
import { CliContext } from "./cli-context/CliContext";
export interface GlobalCliOptions {
    "log-level": LogLevel;
}
export declare function loadProjectAndRegisterWorkspacesWithContext(cliContext: CliContext, args: Omit<loadProject.Args, "context" | "cliName" | "cliVersion">, registerDocsWorkspace?: boolean): Promise<Project>;
