import { CliContext } from "./cli-context/CliContext";
export declare function rerunFernCliAtVersion({ version, cliContext, env }: {
    version: string;
    cliContext: CliContext;
    env?: Record<string, string>;
}): Promise<void>;
